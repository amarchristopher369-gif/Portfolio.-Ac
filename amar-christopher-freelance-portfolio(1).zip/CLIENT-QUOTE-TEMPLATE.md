# Client Project Quote — Template

**Prepared for:** [Client / Business]  
**Project:** [Website / UI design]  
**Date:** [Date]  
**Quote valid until:** [Date]

## Project goals
[Summarize the client's goals and intended audience.]

## Deliverables
- [Pages / screens]
- Responsive frontend for agreed devices
- [Contact form or links — specify whether backend is included]
- Two revision rounds within the agreed scope
- Basic handover notes

## Investment
**Project fee:** ₹[Amount]  
**Payment schedule:** 40% to book the project, 40% after design approval and before final build handoff, 20% before final delivery.

## Timeline
[Estimated timeline after receiving all content and approvals.]

## Not included unless explicitly listed
Backend, database, authentication, CMS, payment gateway, automated email, domain/hosting fees, paid plugins and ongoing maintenance.

## Approval
Client name/signature: ____________________  
Date: ____________________
