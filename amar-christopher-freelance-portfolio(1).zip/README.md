# Amar Christopher — Freelance Portfolio

A responsive, single-page portfolio for GitHub Pages.

## Publish safely
1. Keep your current live website/repository unchanged while reviewing this replacement.
2. Prefer creating a separate repository named `amar-christopher-portfolio` or publishing from a preview branch.
3. Upload `index.html` to the repository root.
4. In GitHub, open Settings → Pages and choose Deploy from a branch, then select `main` and `/ (root)`.
5. Wait for the Pages deployment to complete, then test desktop/mobile, WhatsApp and email links, and every project link before sharing.

## Contact
WhatsApp: +91 80907 02582
Email: amarchristopher369@gmail.com

## Scope accuracy
This portfolio describes UI/UX and frontend services. Backend, databases, authentication, CMS, payment processing and automated email are excluded unless separately scoped and quoted. Project cards are concise portfolio summaries; add verified screenshots, repository links and detailed outcomes before making stronger case-study claims.
