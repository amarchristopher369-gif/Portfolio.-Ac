# Freelance Services & Starting Prices

- **Starter — ₹8,999+**: one-page landing or personal website; responsive frontend; core sections; contact links; two revision rounds.
- **Business — ₹14,999+**: up to five pages; custom visual direction; responsive frontend; basic on-page SEO setup.
- **Custom — ₹24,000+**: larger frontend projects and redesigns; final quote after requirements and scope review.

## Not included unless separately quoted
Backend development, database setup, authentication, CMS, payment integration, automated email, hosting/domain charges, paid subscriptions, and ongoing maintenance.

## Suggested project workflow
Discovery and written scope → 40% booking payment → design direction → 40% after design approval / before final build handoff → final QA and 20% balance → handover.
