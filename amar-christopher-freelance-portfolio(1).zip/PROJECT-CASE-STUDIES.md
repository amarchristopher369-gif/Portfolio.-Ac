# Selected Project Case Studies

These are concise summaries based on the known project portfolio. Add verified screenshots, repository/demo links, dates, exact responsibilities and measurable outcomes before presenting them as full client case studies.

## Called to Cultivate
**Type:** Ministry website / content experience  
**Focus:** Clear presentation of ministry identity, resources and content discovery.  
**Role:** Website design and frontend implementation exploration.  
**Do not claim:** Complete backend, publishing automation or production security unless independently verified.

## Azad Collection
**Type:** Retail storefront  
**Focus:** Product-led browsing and shopping-oriented interface.  
**Role:** Website interface and frontend exploration.  
**Do not claim:** Payment, inventory or order-management integrations unless verified.

## SARA Institute
**Type:** Education / institute website  
**Focus:** Presenting institute information and enquiry pathways.  
**Role:** HTML frontend.  
**Note:** Backend functionality is not included in this project description.

## Habit Tracker
**Type:** Productivity interface  
**Focus:** Habit organization and daily progress presentation.  
**Role:** Frontend interface exploration.

## Medical Store
**Type:** Retail / healthcare storefront concept  
**Focus:** Product categories and responsive navigation.  
**Role:** Frontend concept; do not imply clinical or prescription workflows.

## JourneyMate
**Type:** Travel website concept  
**Focus:** Destination discovery and browsing experience.  
**Role:** Frontend exploration.
